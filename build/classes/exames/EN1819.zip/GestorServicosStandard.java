import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class GestorServicosStandard implements GestorServicos {
	
	@Override
	public Iterator<String> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean registaServico(String ref, Servico servico) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean existeServico(String ref) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Servico eliminaServico(String ref) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Servico getServico(String ref) {
		// TODO Auto-generated method stub
		return null;
	}

}
