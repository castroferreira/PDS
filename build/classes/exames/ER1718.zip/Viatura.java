public interface Viatura{

    String getMatricula();
    String getDescricao();
    String getType();
}