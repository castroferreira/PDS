public interface Imovel {
    public String type();
    public String description();
    public double price();
}
