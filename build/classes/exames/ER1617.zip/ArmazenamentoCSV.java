package Exame;

public class ArmazenamentoCSV {
	private String filename;

	public ArmazenamentoCSV(String filename) {
		this.filename = filename;
	}

	public Pauta lerPauta() {
		throw new UnsupportedOperationException();
	}

	public boolean gravarPauta(Pauta pauta) {
		throw new UnsupportedOperationException();
	}
	
}
