package base;

public class RemoveException extends Exception{
	public RemoveException(){
		System.err.println("Operação não suportada!");
	}
}