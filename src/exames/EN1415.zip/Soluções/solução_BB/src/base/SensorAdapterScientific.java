package base;

import models.AmericanThermo;
import models.ScientificThermo;

public class SensorAdapterScientific implements Sensor {
	
	private ScientificThermo sc;
	private double offset = 0;
	
	public SensorAdapterScientific(ScientificThermo scientific){
		
		sc=scientific;
	}
	
	@Override
	public double measure() {
		
		return (sc.read()-272.15)+offset;
	}

	@Override
	public void calibrate(double cal) {
		offset=cal;
		
	}
	
	@Override
	public String toString() {
		return "ScientificThermo";
	}

}
