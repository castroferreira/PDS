package E1;

public enum Press�o {

	PSI, Bar
}
