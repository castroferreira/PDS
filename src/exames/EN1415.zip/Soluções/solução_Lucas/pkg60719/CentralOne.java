/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg60719;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ricardo Lucas
 */
public class CentralOne implements Central{
    
    private String name;
    private List<BaseStationXL> bases = new ArrayList<>();

    public CentralOne(String name) {
        this.name = name;
    }
    
    @Override
    public void attach(BaseStationXL bxl) {
        bases.add(bxl);
    }

    @Override
    public void notifica(BaseStationXL bxl) {
        System.out.println(this.name + ": Recent info from base station " + bxl.getName() + ": " + bxl.getSensors().size() + " active sensor");
    }
}
