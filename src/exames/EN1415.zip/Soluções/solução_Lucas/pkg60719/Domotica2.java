/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg60719;

import models.AmericanThermo;
import models.EnglishPressureSensor;
import models.EuroThermo;
import models.ScientificThermo;

/**
 *
 * @author Ricardo Lucas
 */
public class Domotica2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        BaseStationXL baseP = new BaseStationXL("Portugal");
        BaseStationXL baseE = new BaseStationXL("Espanha");
        BaseStationXL baseF = new BaseStationXL("França");
        BaseStationXL baseA = new BaseStationXL("Alemanha");
        
        CentralOne central1 = new CentralOne("Central 1");
        CentralTwo central2 = new CentralTwo("Central 2");
        
        baseE.attach(central1);
        baseE.attach(central2);
        baseA.attach(central2);
        
        EuroThermo et = new EuroThermo();
        AmericanThermo at = new AmericanThermo();
        EnglishPressureSensor eps = new EnglishPressureSensor();
        ScientificThermo st = new ScientificThermo();
        
        baseE.connect(et);
        baseE.connect(new SensorAdapter(at));
        baseA.connect(new SensorAdapter(eps));
        
    }
}
