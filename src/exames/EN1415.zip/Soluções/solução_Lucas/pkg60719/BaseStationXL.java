/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg60719;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ricardo Lucas
 */
public class BaseStationXL {
    
    private String name;
    private List<Sensor> sensores = new ArrayList<>();
    private List<Central> centrais = new ArrayList<>();

    public BaseStationXL(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
    public void attach(Central central) {
        centrais.add(central);
    }
    
    public void connect(Sensor s) {
        sensores.add(s);
        update();
    }
    
    public void disconnect(Sensor s) {
        sensores.remove(s);
        update();
    }

    public List<Sensor> getSensors() {
        return sensores;
    }
    
    public void update() {
        for(int i=0; i<centrais.size(); i++) {
            centrais.get(i).notifica(this);
        }
    }
    
}
