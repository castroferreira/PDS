package pkg60719;

import java.util.List;

import models.*;

public class Domotica {

	public static void main(String[] args) {
		
		BaseStation base = new BaseStation("Hall");
		base.connect(new EuroThermo());

		// Problema 1, alinea a) - adicione mais sensores à estação
		// ...
		AmericanThermo at = new AmericanThermo();
                EnglishPressureSensor eps = new EnglishPressureSensor();
                ScientificThermo st = new ScientificThermo();
                
                base.connect(new SensorAdapter(at));
                base.connect(new SensorAdapter(eps));
                base.connect(new SensorAdapter(st));

		List<Sensor> sensors = base.getSensors();		
		// Problema 1, alinea b) - crie uma solução para impedir este tipo de acesso 	
		sensors.add(new EuroThermo()); 
		sensors.remove(0);
		
		System.out.printf("Base station '%s' with %d active sensors\n", base.name(), sensors.size());
		for (Sensor sensor : sensors)
			System.out.printf("%s: %5.2f\n", sensor, sensor.measure());
		for (Sensor sensor : sensors) 
			sensor.calibrate(-1.2);
		System.out.println("\n.... After Calibration ....");
		for (Sensor sensor : sensors) 
			System.out.printf("%s: %5.2f\n", sensor, sensor.measure());
	}
}