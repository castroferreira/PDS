/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg60719;

/**
 *
 * @author Ricardo Lucas
 */
public interface Central {

    public void attach(BaseStationXL bxl);
    public void notifica(BaseStationXL bxl);
    
}
