/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg60719;

import models.*;

/**
 *
 * @author Ricardo Lucas
 */
public class SensorAdapter implements Sensor {

    private double offset = 0;
    private AmericanThermo at;
    private EnglishPressureSensor eps;
    private ScientificThermo st;
    
    public SensorAdapter(AmericanThermo at) {
        this.at = at;
    }
    
    public SensorAdapter(EnglishPressureSensor eps) {
        this.eps = eps;
    }
    
    public SensorAdapter(ScientificThermo st) {
        this.st = st;
    }
    
    @Override
    public double measure() {
        double tmp = 0;
        
        if(at != null) {
            tmp = at.getTemperature();
        } else if(eps != null) {
            tmp = eps.measure();
        } else if(st != null) {
            tmp = st.read();
        }
        
        return tmp + offset;
    }

    @Override
    public void calibrate(double cal) {
        this.offset = cal;
    }
    
    @Override
    public String toString() {
        String name = "";
        
        if(at != null) {
            name = at.toString();
        } else if(eps != null) {
             name = eps.toString();
        } else if(st != null) {
             name = st.toString();
        }
        
        return name;
    }
    
}
