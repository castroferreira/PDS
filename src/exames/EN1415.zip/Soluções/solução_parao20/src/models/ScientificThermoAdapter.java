/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package models;

import domotica1.Sensor;

/**
 *
 * @author Bruno Areias
 */
public class ScientificThermoAdapter extends ScientificThermo implements Sensor{
    private double offset = 0;
    
    @Override
    public double measure() {
        double kelvin = super.read();
        double celsius = kelvin - 273.15;
        return celsius + offset;
    }

    @Override
    public void calibrate(double cal) {
        offset = cal;
    }
}
