/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package models;

import domotica1.Sensor;

/**
 *
 * @author Bruno Areias
 */
public class AmericanThermoAdapter extends AmericanThermo implements Sensor{

    private double offset = 0;
    
    @Override
    public double measure() {
        double fahrenheit = getTemperature();
        double celsius = ((fahrenheit-32)*((double)5/(double)9));
        return celsius + offset;
    }

    @Override
    public void calibrate(double cal) {
        offset = cal;
    }
    

}
