/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package domotica2;

/**
 *
 * @author Bruno Areias
 */
public abstract class Central implements StationObserver{
    
    private int id;

    public Central(int id){
        this.id = id;
    }
    
    @Override
    public String toString(){
        return "Central "+ id;
    }
}
