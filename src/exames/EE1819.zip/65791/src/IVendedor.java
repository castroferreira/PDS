
public interface IVendedor extends Iterable<String> {

    public boolean existePropriedade(String code);
    public boolean addPropriedade(String code, Propriedade proper);
    public Propriedade removePropriedade(String code);
    public void addPropriedade(String code, Moradia moradia);
    public void addPropriedade(String code, String str);
    public Propriedade getPropriedade(String code);

    public void addPropriedade(String code, PackPropers pack);
}
