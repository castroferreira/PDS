
/**
 *
 * @author andreia
 */
public class PackPropers {
    
    private String pack, info;

    public PackPropers(String pack, String info) {
        this.pack = pack;
        this.info = info;
    }

    public String getPack() {
        return pack;
    }

    public String getInfo() {
        return info;
    }

    void add(String code) {
        
    }

    @Override
    public String toString() {
        return " " + pack + ", " + info;
    }
    
    
}
