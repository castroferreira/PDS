
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author andreia
 */
public class VendeTralhaEspecial {
    
    private String nome;
    private List<Cliente> list;

    public VendeTralhaEspecial() {
        list = new ArrayList<Cliente>();
    }

    public VendeTralhaEspecial(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return " " + nome + " >> Novo imovel: ";
    }

    void add(Cliente cliente) {
        list.add(cliente);
    }

    void addPropriedade(String code, String moradia) {
    }
    
}
