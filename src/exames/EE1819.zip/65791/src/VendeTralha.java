
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author andreia
 */
public class VendeTralha implements IVendedor {

    private Map<String, Propriedade> map = new HashMap<String, Propriedade>();

    private List<Apartamento> list_apartamento;
    private List<Moradia> list_moradia;

    public VendeTralha() {
        list_apartamento = new ArrayList<>();
        list_moradia = new ArrayList<>();
    }

    @Override
    public boolean existePropriedade(String code) {
        return map.containsKey(code);
    }

    @Override
    public boolean addPropriedade(String code, Propriedade proper) {
        map.put(code, proper);
        return false;
    }

    @Override
    public Propriedade removePropriedade(String code) {
        if (map.containsKey(code)) {
            return map.remove(code);
        }
        return new NullPropriedade();
    }

    @Override
    public Iterator<String> iterator() {
        return map.keySet().iterator();
    }

    @Override
    public void addPropriedade(String code, Moradia moradia) {
        map.put(code, (Propriedade) moradia);
    }

    @Override
    public void addPropriedade(String code, String str) {
    }

    @Override
    public Propriedade getPropriedade(String code) {
        if (map.containsKey(code)) {
            return map.get(code);
        }
        return null;
    }

    @Override
    public void addPropriedade(String code, PackPropers pack) {
    }

}
