
/**
 *
 * @author andreia
 */
public class NullPropriedade implements Propriedade {

    public NullPropriedade() {
    }

    @Override
    public String toString() {
        return "PropriedadeVazia ["
                + "type=nao existe"
                + ", description=nao existe"
                + ", price=" + 0.0
                + "],";
    }

    @Override
    public String type() {
        return null;
    }

    @Override
    public String description() {
        return null;
    }

    @Override
    public double price() {
        return 0;
    }
}
