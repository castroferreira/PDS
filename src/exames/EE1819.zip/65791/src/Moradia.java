
import java.util.*;

/**
 *
 * @author andreia
 */
public class Moradia implements Propriedade {

    private String type, description, caracteriticas;
    private int price;

    private List<Propriedade> propriedade = new ArrayList<>();

    public Moradia(String type, String description, int price) {
        this.type = type;
        this.description = description;
        this.price = price;
    }

    public Moradia(String type, String description, int price, String caracteriticas) {
        this.type = type;
        this.description = description;
        this.price = price;
        this.caracteriticas = caracteriticas;
    }

    @Override
    public String type() {
        return type;
    }

    @Override
    public String description() {
        return description;
    }

    @Override
    public double price() {
        return price;
    }

    public String getCaracteriticas() {
        return caracteriticas;
    }

    public String addChar(String caracteristica) {
        return caracteristica = getCaracteriticas();
    }

    @Override
    public String toString() {
//        return "Moradia\t[" + "type=" + type + ", description=" + description + ", price=" + price + ']' + "\n\tCaracteristicas: " + caracteriticas;

        StringBuilder sb = new StringBuilder();
        sb.append("Moradia\t[" + "type=" + type
                + ", description=" + description
                + ", price=" + price + "]"
                + "\n\tCaracteristicas: [" + caracteriticas + "]"
        );
        for (Propriedade p : propriedade) {
            sb.append("\n   " + p.toString());
        }

        return sb.toString();
    }
}
