
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author andreia
 */
public class Apartamento implements Propriedade {

    private String type, description;
    private int price;

    private List<Propriedade> propriedade = new ArrayList<>();

    public Apartamento(String type, String description, int price) {
        this.type = type;
        this.description = description;
        this.price = price;
    }

    @Override
    public String type() {
        return type;
    }

    @Override
    public String description() {
        return description;
    }

    @Override
    public double price() {
        return price;
    }

    @Override
    public String toString() {
//        return "Apartamento\t[" + "type=" + type + ", description=" + description + ", price=" + price + ']';

        StringBuilder sb = new StringBuilder();
        sb.append("Apartamento\t[" + "type=" + type
                + ", description=" + description
                + ", price=" + price + "]"
        );
        for (Propriedade p : propriedade) {
            sb.append("\n   " + p.toString());
        }

        return sb.toString();
    }
}
