
public interface Propriedade {
	public String type();
	public String description();
	public double price();

}
