package ExameRecurso.AbstractFactory;

/**
 *
 * @author andreia
 */
public class Blue implements Color{

    @Override
    public void fill() {
        System.out.println("Blue");
    }
}