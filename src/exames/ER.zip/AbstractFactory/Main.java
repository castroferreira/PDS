package ExameRecurso.AbstractFactory;

/**
 *
 * @author andreia
 */
public class Main {
    public static void main(String[] args) {
        AbstractFactory shape = FactoryProducer.getFactory("Shape");
        
        Shape shape1 = shape.getShape("Circle");
        shape1.draw();
        
        Shape shape2 = shape.getShape("Retangule");
        shape2.draw();
        
        Shape shape3 = shape.getShape("Square");
        shape3.draw();
       
        AbstractFactory color = FactoryProducer.getFactory("Color");
        
        Color color1 = color.getColor("Red");
        color1.fill();
        
        Color color2 = color.getColor("Green");
        color2.fill();
        
        Color color3 = color.getColor("Blue");
        color3.fill();
    }
}
