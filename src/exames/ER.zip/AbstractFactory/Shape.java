package ExameRecurso.AbstractFactory;

/**
 *
 * @author andreia
 */
public interface Shape {
    public void draw();
}