package ExameRecurso.AbstractFactory;

/**
 *
 * @author andreia
 */
public class Retangule implements Shape{

    @Override
    public void draw() {
        System.out.println("Retangule");
    }
}