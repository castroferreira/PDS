package ExameRecurso.AbstractFactory;

/**
 *
 * @author andreia
 */
public interface Color {

    public void fill();
}