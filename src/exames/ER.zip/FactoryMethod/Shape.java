package ExameRecurso.FactoryMethod;

/**
 *
 * @author andreia
 */
public interface Shape {
    public void draw();
}