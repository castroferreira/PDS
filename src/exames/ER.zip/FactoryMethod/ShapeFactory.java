package ExameRecurso.FactoryMethod;

/**
 *
 * @author andreia
 */
public class ShapeFactory {

    public Shape getShape(String shapeType) {

        if (shapeType.equalsIgnoreCase("Circle")) {
            return new Circle();
        }

        if (shapeType.equalsIgnoreCase("Retangule")) {
            return new Retangule();
        }

        if (shapeType.equalsIgnoreCase("Square")) {
            return new Square();
        }
        
        if (shapeType == null)
            return null;

        return null;
    }
}
