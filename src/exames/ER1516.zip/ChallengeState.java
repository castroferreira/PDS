package Exame;
public enum ChallengeState {
	OPEN, CLOSED, SOLVED;
}
