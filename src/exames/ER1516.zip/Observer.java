package Exame;

/**
 *
 * @author Beatriz Marques
 */
public abstract class Observer {
    
    protected ChallengeSubject subject;

    public abstract void update();
}
