package Exame;
public enum ChallengeType {
	PRATICAL_CHALLENGE, DESIGN_AND_MODELLING;
}
